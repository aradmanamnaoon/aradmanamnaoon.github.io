# Psychological Questionnaire Dataset — Bilingual Exploratory Audit
## تحلیل اکتشافی دو‌زبانهٔ داده‌های پرسشنامه‌های روان‌شناختی

**Status / وضعیت:** PUBLIC RELEASE CANDIDATE — NOT YET APPROVED FOR POSTING / پیش‌نویس انتشار عمومی، نیازمند تأیید

**Date:** 2026-10-12  
**Scope:** SPSS file with 240 recorded rows, 89 original variables, 76 questionnaire items, 2 coded groups.

### Start here / از اینجا شروع کنید

- `reports/` — complete English and Persian academic-style reports in `.docx` and `.pdf`, with methods, analyses, diagnostic tests, limitations, and R appendix.
- `documentation/FINDINGS_EN.md` — plain-English walkthrough of the dataset, variables, numerical findings, and interpretation restrictions.
- `documentation/FINDINGS_FA.md` — توضیح کامل و قابل فهم داده‌ها و یافته‌ها به فارسی.
- `documentation/statistics_explained_EN_FA.md` — statistical concepts explained in both languages.
- `results/` — aggregate bilingual demographics, psychological score summaries, quality metrics, reliability, variable dictionary, and *explicitly labelled diagnostic-only* inferential tables.
- `figures/` — graphical results (descriptive/diagnostic only).
- `web_preview/index.html` — locally openable bilingual interactive preview using ONLY aggregated summaries.
- `code/` — Python script and parser that reproduce the public aggregates from authorized access to the SAV; corrected R script provided as **not runtime tested**; DAX measures.
- `metadata/` — publication decision notes, methods, licensing and citation templates, and file hashes.

### Why this is NOT a confirmatory psychology finding

1. Of 240 records, only **86 distinct combinations** of all 76 item responses occur; **239 records share a pattern** with at least one other record.
2. Across the two coded groups, **119/120 aligned record pairs** have identical answers to all 76 questionnaire items.
3. The stored TOTALA group difference is **+4.625**, while the arithmetic A1–A13 sum difference is only **+0.075**. Direct sums are NOT validated questionnaire scores.
4. **31 D-item answers** across **5 records** fall outside the documented binary response categories.
5. The SPSS does not establish what `fire` and `non` mean, whether cases are paired, the sampling design, or the authorized reverse-scoring rules.

Therefore **group-comparison p-values and model confidence intervals are provided only as diagnostic calculations; do not present them as valid population-inference results**.

### Data-sharing boundary / حریم خصوصی

This *public candidate* intentionally includes **aggregated results only**, NOT row-level psychological questionnaires. The full private reviewer ZIP contains the unchanged `.sav` and complete participant-level CSV **under `PRIVATE_REVIEW_ONLY/`**. Human-subject permissions, participant consent, intended sharing scope, potential identifiability, licensing and data ownership are unverified. **Do not copy the private folder into a public website or repository.**

این بستهٔ عمومی شامل آمار تجمیعی است و پاسخ‌های فردبه‌فرد را منتشر نمی‌کند. نسخهٔ کامل برای بازبینی، فایل خام و داده‌های سطح فرد را در پوشهٔ خصوصی نگه می‌دارد. انتشار عمومی اطلاعات فردی، نیازمند بررسی مجوز، رضایت شرکت‌کنندگان و خطر شناسایی مجدد است.

### Reproduction / بازتولید

```bash
python -m pip install -r code/requirements.txt
python code/reproduce_public_aggregates.py "/private/path/to/raw.sav" regenerated_results
```

The Python aggregate build was executed and validated against the original SPSS file. The bundled parser supports this specific SPSS binary structure and does not replace a general SPSS import library. The R script has its SPSS name-normalization bug corrected but could not be runtime-tested here. No native `.pbix` is included.

### Mandatory prepublication decisions

See `metadata/PUBLICATION_APPROVAL_CHECKLIST_EN_FA.md`. Obtain study owner authorization, confirm original data provenance, questionnaire manuals, human-subject consent/data sharing approval, dataset license, authorship and group definitions. Until then, describe this work as an **exploratory data audit**.
